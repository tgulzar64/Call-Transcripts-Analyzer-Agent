"use client";

import axios from "axios";
import { useState, ChangeEvent } from "react";

type EmotionEntry = {
  minute: number;
  tone: string;
};

type CallAnalysis = {
  call_id: string;
  category: string;
  emotion_timeline: EmotionEntry[];
  agent_empathy_score: number;
  coaching_suggestions: string[];
  customer_persona: string;
  call_highlights: string[];
};

export default function UploadPage() {
  const [fileName, setFileName] = useState<string | null>(null);
  const [fileContent, setFileContent] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [parsedCalls, setParsedCalls] = useState<CallAnalysis[]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;

  const uploadAndProcessFile = async (file: File) => {
    setIsLoading(true);
    setErrorMessage(null);
    setParsedCalls([]);

    const urlUpload = `${baseUrl}/neuralseek/upload-file`;
    const urlMaistro = `${baseUrl}/neuralseek/maistro`;

    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("url_name", "staging-talha");

      const uploadResponse = await axios.post(urlUpload, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      const uploadedFileName = uploadResponse.data.fn;
      if (!uploadedFileName) throw new Error("Missing filename from upload.");

      const maistroBody = {
        url_name: "staging-talha",
        agent: "analyze_transcripts",
        params: [{ name: "docName", value: uploadedFileName }],
        options: {
          returnVariables: true,
          returnVariablesExpanded: true,
        },
      };

      const maistroResponse = await axios.post(urlMaistro, maistroBody, {
        headers: { "Content-Type": "application/json" },
      });

      let rawAnswer = maistroResponse.data?.answer;
      if (!rawAnswer) throw new Error("No answer from Maistro.");

      // ✅ Parse double-encoded string
      const fixedString = rawAnswer.replace(/(\r\n|\n|\r)/gm, "").trim();
      const parsedJson = JSON.parse(fixedString);
      setParsedCalls(parsedJson);
    } catch (error: any) {
      console.error("Processing error:", error);
      setErrorMessage("❌ Upload or parsing failed.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      setFileContent(text);
    };
    reader.readAsText(file);

    uploadAndProcessFile(file);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-blue-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-indigo-500 rounded-full mix-blend-multiply filter blur-xl opacity-10 animate-pulse"></div>
      </div>

      <div className="relative z-10 p-4 md:p-8 flex flex-col items-center justify-start">
        {/* Header Section */}
        <div className="text-center mb-12 animate-fade-in">
          <h1 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent mb-4">
            Upload Transcript
          </h1>
          <p className="text-gray-300 text-lg max-w-2xl mx-auto leading-relaxed">
            Transform your call transcripts into actionable insights with AI-powered analysis
          </p>
        </div>

        {/* Upload Section */}
        <div className="mb-10">
          <label className="group relative cursor-pointer">
            <input
              type="file"
              accept=".txt"
              onChange={handleFileUpload}
              className="hidden"
            />
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-4 rounded-2xl transition-all duration-300 transform group-hover:scale-105 group-hover:shadow-2xl group-hover:shadow-purple-500/25 flex items-center gap-3 text-lg font-semibold">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
              </svg>
              Choose File to Analyze
            </div>
          </label>
        </div>

        {/* Loading State */}
        {isLoading && (
          <div className="mb-8 bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl px-6 py-4 animate-pulse">
            <div className="flex items-center gap-3 text-blue-400 font-medium">
              <div className="animate-spin rounded-full h-5 w-5 border-2 border-blue-400 border-t-transparent"></div>
              Uploading and analyzing your transcript...
            </div>
          </div>
        )}

        {/* Error Message */}
        {errorMessage && (
          <div className="mb-8 bg-red-500/10 backdrop-blur-sm border border-red-500/30 rounded-2xl px-6 py-4 text-red-400 font-semibold">
            {errorMessage}
          </div>
        )}

        {/* Results Section */}
        {fileName && fileContent && parsedCalls.length > 0 && (
          <div className="w-full max-w-7xl grid grid-cols-1 xl:grid-cols-2 gap-8 animate-fade-in">

            {/* Original Transcript */}
            <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-3xl p-8 shadow-2xl">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-xl flex items-center justify-center">
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white">Transcript</h2>
                  <p className="text-gray-300 text-sm">Uploaded: {fileName}</p>
                </div>
              </div>

              <div className="bg-black/20 rounded-2xl p-6 max-h-[70vh] overflow-auto custom-scrollbar">
                <pre className="text-gray-200 text-sm leading-relaxed whitespace-pre-wrap font-mono">
                  {fileContent}
                </pre>
              </div>
            </div>

            {/* Analysis Results */}
            <div className="space-y-8 max-h-[80vh] overflow-auto custom-scrollbar">
              {parsedCalls.map((call, index) => (
                <div key={index} className="bg-white/10 backdrop-blur-md border border-white/20 rounded-3xl p-8 shadow-2xl hover:bg-white/15 transition-all duration-300">

                  {/* Call Header */}
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-blue-500 rounded-xl flex items-center justify-center">
                      <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                      </svg>
                    </div>
                    <h2 className="text-2xl font-bold text-white">Call ID: {call.call_id}</h2>
                  </div>

                  {/* Call Info Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                    <div className="bg-black/20 rounded-xl p-4 text-center">
                      <p className="text-gray-400 text-sm mb-1">Category</p>
                      <p className="text-white font-semibold">{call.category}</p>
                    </div>
                    <div className="bg-black/20 rounded-xl p-4 text-center">
                      <p className="text-gray-400 text-sm mb-1">Customer Persona</p>
                      <p className="text-white font-semibold">{call.customer_persona}</p>
                    </div>
                    <div className="bg-black/20 rounded-xl p-4 text-center">
                      <p className="text-gray-400 text-sm mb-1">Empathy Score</p>
                      <p className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                        {call.agent_empathy_score}
                      </p>
                    </div>
                  </div>

                  {/* Emotion Timeline */}
                  <div className="mb-8">
                    <div className="flex items-center gap-2 mb-4">
                      <div className="w-6 h-6 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-lg flex items-center justify-center">
                        <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                        </svg>
                      </div>
                      <h3 className="text-lg font-semibold text-white">Emotion Timeline</h3>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {call.emotion_timeline.map((entry, i) => (
                        <div key={i} className="bg-gradient-to-r from-gray-800/50 to-gray-700/50 rounded-xl px-4 py-3 border border-gray-600/30">
                          <p className="text-gray-300 text-sm">Minute {entry.minute}</p>
                          <p className="text-white font-medium capitalize">{entry.tone}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Coaching Suggestions */}
                  <div className="mb-8">
                    <div className="flex items-center gap-2 mb-4">
                      <div className="w-6 h-6 bg-gradient-to-r from-green-500 to-teal-500 rounded-lg flex items-center justify-center">
                        <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                        </svg>
                      </div>
                      <h3 className="text-lg font-semibold text-white">Coaching Suggestions</h3>
                    </div>
                    <div className="space-y-3">
                      {call.coaching_suggestions.map((tip, i) => (
                        <div key={i} className="flex items-start gap-3 p-4 bg-black/20 rounded-xl">
                          <div className="w-2 h-2 bg-green-400 rounded-full mt-2 flex-shrink-0"></div>
                          <p className="text-gray-200 leading-relaxed">{tip}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Call Highlights */}
                  <div>
                    <div className="flex items-center gap-2 mb-4">
                      <div className="w-6 h-6 bg-gradient-to-r from-pink-500 to-rose-500 rounded-lg flex items-center justify-center">
                        <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
                        </svg>
                      </div>
                      <h3 className="text-lg font-semibold text-white">Call Highlights</h3>
                    </div>
                    <div className="space-y-3">
                      {call.call_highlights.map((highlight, i) => (
                        <div key={i} className="flex items-start gap-3 p-4 bg-black/20 rounded-xl">
                          <div className="w-2 h-2 bg-pink-400 rounded-full mt-2 flex-shrink-0"></div>
                          <p className="text-gray-200 leading-relaxed">{highlight}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <style jsx>{`
    .custom-scrollbar {
      scrollbar-width: thin;
      scrollbar-color: rgba(147, 197, 253, 0.5) transparent;
    }
    
    .custom-scrollbar::-webkit-scrollbar {
      width: 6px;
    }
    
    .custom-scrollbar::-webkit-scrollbar-track {
      background: transparent;
    }
    
    .custom-scrollbar::-webkit-scrollbar-thumb {
      background-color: rgba(147, 197, 253, 0.5);
      border-radius: 3px;
    }
    
    .custom-scrollbar::-webkit-scrollbar-thumb:hover {
      background-color: rgba(147, 197, 253, 0.7);
    }
    
    .animate-fade-in {
      animation: fadeIn 0.6s ease-out;
    }
    
    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
  `}</style>
    </div>
  );
}
