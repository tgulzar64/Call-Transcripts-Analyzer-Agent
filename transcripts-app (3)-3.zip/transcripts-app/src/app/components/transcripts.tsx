// app/transcript-analyzer/page.tsx
"use client";

import axios from "axios";
import React, { useState } from "react";

/* =========================
   TYPES (declare first)
   ========================= */

// Allowed tone names
type ToneName =
    | "frustrated"
    | "neutral"
    | "relieved"
    | "curious"
    | "polite"
    | "demanding";

// Data structures
type TimelinePoint = { minute: number; tone: ToneName };
export type Result = {
    callId: string;
    category: string;
    emotion_timeline: TimelinePoint[];
    agent_empathy_score: number;
    coaching_suggestions: string[];
    customer_persona: string;
    call_highlights: string[];
};

// Button variants
type ButtonVariant = "primary" | "secondary" | "ghost";

/* =========================
   CONSTANTS (typed)
   ========================= */

const toneConfig: Record<
    ToneName,
    { color: string; bg: string; border: string; icon: string }
> = {
    frustrated: {
        color: "#ef4444",
        bg: "bg-red-50",
        border: "border-red-200",
        icon: "😤",
    },
    neutral: {
        color: "#6b7280",
        bg: "bg-gray-50",
        border: "border-gray-200",
        icon: "😐",
    },
    relieved: {
        color: "#10b981",
        bg: "bg-emerald-50",
        border: "border-emerald-200",
        icon: "😌",
    },
    curious: {
        color: "#3b82f6",
        bg: "bg-blue-50",
        border: "border-blue-200",
        icon: "🤔",
    },
    polite: {
        color: "#8b5cf6",
        bg: "bg-purple-50",
        border: "border-purple-200",
        icon: "😊",
    },
    demanding: {
        color: "#f59e0b",
        bg: "bg-amber-50",
        border: "border-amber-200",
        icon: "😠",
    },
};

/* =========================
   HELPERS (typed)
   ========================= */

const splitByCallId = (text: string): string[] =>
    text
        .split(/(?=Call ID:\s*[^\s\r\n]+)/g)
        .map((s) => s.trim())
        .filter(Boolean);

async function analyzeCall(block: string) {
    console.log(block);

    try {
        const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;
        const urlMaistro = `${baseUrl}/neuralseek/maistro`;
        const maistroCallBody = {
            url_name: "staging-talha",
            agent: "Transcript_Expert",
            params: [
                {
                    name: "callTranscripts",
                    value: block
                }
            ],
            options: {
                returnVariables: false,
                returnVariablesExpanded: false
            }
        };
        await axios.post(urlMaistro, maistroCallBody, {
            headers: {
                'Content-Type': 'application/json',
            },
        });
        //await fetchFilesByPath("/files/pii-files");
        //setIsLoadingAnalysis(false);

    } catch (err) {
        console.error("Error fetching files:", err);
        //setIsLoadingAnalysis(false);
    }


}

/* =========================
   UI COMPONENTS (fully typed)
   ========================= */

interface GlowingButtonProps {
    children: React.ReactNode;
    onClick?: () => void;
    disabled?: boolean;
    variant?: ButtonVariant;
    className?: string;
    type?: "button" | "submit";
}

const GlowingButton: React.FC<GlowingButtonProps> = ({
    children,
    onClick,
    disabled = false,
    variant = "primary",
    className = "",
    type = "button",
}) => {
    const baseClasses =
        "relative px-6 py-3 rounded-xl font-semibold transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none";

    const variants: Record<ButtonVariant, string> = {
        primary:
            "bg-gradient-to-r from-purple-600 to-blue-600 text-white shadow-lg shadow-purple-500/25 hover:shadow-xl hover:shadow-purple-500/40",
        secondary:
            "bg-white text-gray-700 border-2 border-gray-200 hover:border-purple-300 hover:shadow-lg",
        ghost: "bg-transparent text-gray-600 border border-gray-300 hover:bg-gray-50",
    };

    return (
        <button
            type={type}
            className={`${baseClasses} ${variants[variant]} ${className}`}
            onClick={onClick}
            disabled={disabled}
        >
            {variant === "primary" && (
                <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-purple-600 to-blue-600 opacity-0 hover:opacity-100 transition-opacity duration-300 blur" />
            )}
            <span className="relative z-10">{children}</span>
        </button>
    );
};

interface AnimatedCardProps {
    children: React.ReactNode;
    className?: string;
}

const AnimatedCard: React.FC<AnimatedCardProps> = ({ children, className = "" }) => (
    <div
        className={`bg-white rounded-3xl shadow-xl border border-gray-100 p-8 transition-all duration-300 hover:shadow-2xl hover:scale-[1.02] ${className}`}
    >
        {children}
    </div>
);

interface ScoreRingProps {
    score: number;
    max?: number;
    size?: number;
    strokeWidth?: number;
}

const ScoreRing: React.FC<ScoreRingProps> = ({
    score,
    max = 10,
    size = 120,
    strokeWidth = 8,
}) => {
    const radius = (size - strokeWidth) / 2;
    const circumference = radius * 2 * Math.PI;
    const strokeDasharray = circumference;
    const strokeDashoffset = circumference - (score / max) * circumference;

    const getScoreColor = (s: number) => (s >= 8.5 ? "#10b981" : s >= 7 ? "#f59e0b" : "#ef4444");

    return (
        <div className="relative flex items-center justify-center">
            <svg width={size} height={size} className="transform -rotate-90">
                <circle cx={size / 2} cy={size / 2} r={radius} stroke="#e5e7eb" strokeWidth={strokeWidth} fill="transparent" />
                <circle
                    cx={size / 2}
                    cy={size / 2}
                    r={radius}
                    stroke={getScoreColor(score)}
                    strokeWidth={strokeWidth}
                    fill="transparent"
                    strokeDasharray={strokeDasharray}
                    strokeDashoffset={strokeDashoffset}
                    strokeLinecap="round"
                    className="transition-all duration-1000 ease-out"
                />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                    <div className="text-3xl font-bold text-gray-900">{score}</div>
                    <div className="text-sm text-gray-500">/{max}</div>
                </div>
            </div>
        </div>
    );
};

/* =========================
   PAGE (was App)
   ========================= */

export default function TranscriptAnalyzerPage() {
    const [calls, setCalls] = useState<string[]>([]);
    const [activeIdx, setActiveIdx] = useState<number>(0);
    const [results, setResults] = useState<Record<string, Result>>({});
    const [pasteText, setPasteText] = useState<string>("");
    const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
    const [showResults, setShowResults] = useState<boolean>(false);

    const activeBlock: string | undefined = calls[activeIdx];
    const activeId: string | undefined = activeBlock?.match(/Call ID:\s*([^\s\r\n]+)/i)?.[1];
    const activeJson: Result | undefined = activeId ? results[activeId] : undefined;

    const [isLoading, setIsLoading] = useState(false);


    const uploadAndProcessFile = async (file: File) => {
        setIsLoading(true);

        const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;
        const urlUpload = `${baseUrl}/neuralseek/upload-file`;
        const urlMaistro = `${baseUrl}/neuralseek/maistro`;

        try {
            const formData = new FormData();
            formData.append("file", file);
            formData.append("url_name", "staging-talha");

            // Use axios for upload
            const uploadResponse = await axios.post(urlUpload, formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });
            const uploadedFileName = uploadResponse.data.fn;
            console.log(uploadedFileName)
            // if (uploadedFileName) {
            //     const maistroCallBody = {
            //         url_name: "staging-pii-detection-demo",
            //         agent: "remove-pii",
            //         params: [
            //             { name: "name", value: uploadedFileName },
            //         ],
            //         options: {
            //             returnVariables: true,
            //             returnVariablesExpanded: true,
            //         },
            //     };
            //     const piiResponse = await axios.post(urlMaistro, maistroCallBody, {
            //         headers: {
            //             'Content-Type': 'application/json',
            //         },
            //     });
            //     const piiData = piiResponse.data;
            //     //setPiiVariables(piiData);
            // }

        } catch (error) {
            console.error(`Error processing file ${file.name}:`, error);
        } finally {
            setIsLoading(false);
        }
    };

    const onUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        await uploadAndProcessFile(file)

        const text = await file.text();
        const blocks = splitByCallId(text);
        setCalls(blocks);
        setActiveIdx(0);
        setShowResults(false);
        e.target.value = "";
    };

    const addPasted = () => {
        if (!pasteText.trim()) return;
        const blocks = splitByCallId(pasteText);
        setCalls((prev) => [...prev, ...blocks]);
        setPasteText("");
        if (!calls.length && blocks.length) setActiveIdx(0);
    };

    const runAnalysis = async () => {
        if (!activeBlock) return;
        setIsAnalyzing(true);
        await new Promise((r) => setTimeout(r, 1500));
        const res = analyzeCall(activeBlock);
        //setResults((prev) => ({ ...prev, [res.callId]: res }));
        setShowResults(true);
        setIsAnalyzing(false);
    };

    const runAllAnalysis = async () => {
        if (!calls.length) return;
        setIsAnalyzing(true);
        const map: Record<string, Result> = {};
        for (let i = 0; i < calls.length; i++) {
            await new Promise((r) => setTimeout(r, 500));
            const rlt = analyzeCall(calls[i]);
            //map[rlt.callId] = rlt;
        }
        setResults((prev) => ({ ...prev, ...map }));
        setShowResults(true);
        setIsAnalyzing(false);
    };

    const handleAnalysis = async () => {
        //setIsLoadingAnalysis(true);
        try {
            const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;
            const urlMaistro = `${baseUrl}/neuralseek/maistro`;
            const maistroCallBody = {
                url_name: "staging-talha",
                agent: "Transcript_Expert",
                params: [
                    {
                        name: "callTranscripts",
                        value: pasteText
                    }
                ],
                options: {
                    returnVariables: false,
                    returnVariablesExpanded: false
                }
            };
            await axios.post(urlMaistro, maistroCallBody, {
                headers: {
                    'Content-Type': 'application/json',
                },
            });
            //await fetchFilesByPath("/files/pii-files");
            //setIsLoadingAnalysis(false);

        } catch (err) {
            console.error("Error fetching files:", err);
            //setIsLoadingAnalysis(false);
        }
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
            {/* Header */}
            <header className="sticky top-0 z-50 backdrop-blur-xl bg-white/80 border-b border-gray-200">
                <div className="max-w-7xl mx-auto px-6 py-4">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                            <div className="w-12 h-12 bg-gradient-to-r from-purple-600 to-blue-600 rounded-2xl flex items-center justify-center text-white font-bold text-xl">
                                TA
                            </div>
                            <div>
                                <h1 className="text-2xl font-bold gradient-text">Transcript Analyzer</h1>
                                <p className="text-sm text-gray-500">Advanced Call Analysis Platform</p>
                            </div>
                        </div>

                        <div className="flex items-center space-x-4">
                            <div className="flex items-center space-x-2 px-4 py-2 bg-gray-100 rounded-xl">
                                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                                <span className="text-sm font-medium text-gray-700">{calls.length} calls loaded</span>
                            </div>
                            <label className="cursor-pointer">
                                <input type="file" accept=".txt" onChange={onUpload} className="hidden" />
                                <GlowingButton variant="primary">📁 Upload Transcripts</GlowingButton>
                            </label>
                        </div>
                    </div>
                </div>
            </header>

            <main className="max-w-7xl mx-auto px-6 py-8">
                {/* Input Section */}
                {(!calls.length || !showResults) && (
                    <div className="space-y-8">
                        <AnimatedCard className="text-center py-16">
                            <div className="space-y-6">
                                <div className="w-24 h-24 mx-auto bg-gradient-to-r from-purple-100 to-blue-100 rounded-full flex items-center justify-center">
                                    <span className="text-4xl">🎯</span>
                                </div>

                                <div>
                                    <h2 className="text-3xl font-bold text-gray-900 mb-2">Analyze Customer Conversations</h2>
                                    <p className="text-lg text-gray-600">
                                        Upload transcript files or paste content to get AI-powered insights
                                    </p>
                                </div>

                                <div className="flex justify-center space-x-4">
                                    <label className="cursor-pointer relative inline-block">
                                        <input
                                            type="file"
                                            accept=".txt"
                                            onChange={onUpload}
                                            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                                        />
                                        <GlowingButton variant="primary" className="text-lg px-8 py-4">
                                            📄 Choose File
                                        </GlowingButton>
                                    </label>

                                    {calls.length > 0 && (
                                        <GlowingButton variant="secondary" onClick={runAllAnalysis} className="text-lg px-8 py-4">
                                            ⚡ Analyze All ({calls.length})
                                        </GlowingButton>
                                    )}
                                </div>

                            </div>
                        </AnimatedCard>

                        <AnimatedCard>
                            <div className="space-y-4">
                                <div className="flex items-center justify-between">
                                    <h3 className="text-xl font-semibold text-gray-900">Quick Paste</h3>
                                    <GlowingButton onClick={addPasted} variant="secondary">➕ Add Content</GlowingButton>
                                </div>
                                <textarea
                                    value={pasteText}
                                    onChange={(e) => setPasteText(e.target.value)}
                                    rows={6}
                                    placeholder="Paste your transcripts here... Include 'Call ID: xxx' for better organization"
                                    className="w-full p-4 border-2 border-gray-200 rounded-xl focus:border-purple-400 focus:ring focus:ring-purple-200 resize-none transition-colors"
                                />
                            </div>
                        </AnimatedCard>
                    </div>
                )}

                {/* Analysis View */}
                {calls.length > 0 && (
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                        {/* Left */}
                        <AnimatedCard className="relative">
                            <div className="flex items-center justify-between mb-6">
                                <div>
                                    <h3 className="text-xl font-semibold text-gray-900">Call {activeIdx + 1} of {calls.length}</h3>
                                    <p className="text-sm text-gray-500 mt-1">{activeId ?? `call_${activeIdx + 1}`}</p>
                                </div>
                                <div className="flex items-center space-x-2">
                                    <button
                                        onClick={() => setActiveIdx((i) => Math.max(0, i - 1))}
                                        disabled={activeIdx === 0}
                                        className="p-2 rounded-lg bg-gray-100 hover:bg-gray-200 disabled:opacity-50 transition-colors"
                                    >
                                        ←
                                    </button>
                                    <button
                                        onClick={() => setActiveIdx((i) => Math.min(calls.length - 1, i + 1))}
                                        disabled={activeIdx >= calls.length - 1}
                                        className="p-2 rounded-lg bg-gray-100 hover:bg-gray-200 disabled:opacity-50 transition-colors"
                                    >
                                        →
                                    </button>
                                </div>
                            </div>

                            <div className="bg-gray-50 rounded-xl p-4 h-80 overflow-y-auto border-2 border-gray-100">
                                <pre className="text-sm text-gray-700 whitespace-pre-wrap font-mono">{activeBlock}</pre>
                            </div>

                            <div className="flex justify-center mt-6">
                                <GlowingButton onClick={runAnalysis} disabled={!activeBlock || isAnalyzing} className={isAnalyzing ? "animate-pulse" : ""}>
                                    {isAnalyzing ? "🔄 Analyzing..." : "🧠 Analyze This Call"}
                                </GlowingButton>
                            </div>
                        </AnimatedCard>

                        {/* Right */}
                        <div className="space-y-6">
                            {activeJson ? (
                                <>
                                    <AnimatedCard className="text-center">
                                        <h3 className="text-lg font-semibold text-gray-900 mb-4">Empathy Score</h3>
                                        <ScoreRing score={activeJson.agent_empathy_score} />
                                        <p className="mt-4 text-sm text-gray-600">
                                            Agent demonstrated {activeJson.agent_empathy_score >= 8 ? "excellent" : activeJson.agent_empathy_score >= 7 ? "good" : "needs improvement"} empathy
                                        </p>
                                    </AnimatedCard>

                                    <AnimatedCard>
                                        <h3 className="text-lg font-semibold text-gray-900 mb-4">Emotion Journey</h3>
                                        <div className="space-y-3">
                                            {activeJson.emotion_timeline.map((point, idx) => {
                                                const cfg = toneConfig[point.tone] || toneConfig.neutral;
                                                return (
                                                    <div key={`${point.tone}-${idx}`} className="flex items-center space-x-4 p-3 rounded-xl bg-gray-50">
                                                        <div className="text-2xl">{cfg.icon}</div>
                                                        <div className="flex-1">
                                                            <div className="flex items-center space-x-2">
                                                                <span className="font-medium text-gray-900 capitalize">{point.tone}</span>
                                                                <span className="text-xs text-gray-500">• Min {point.minute}</span>
                                                            </div>
                                                        </div>
                                                        <div className="w-4 h-4 rounded-full" style={{ backgroundColor: cfg.color }} />
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    </AnimatedCard>

                                    <div className="grid grid-cols-1 gap-4">
                                        <AnimatedCard>
                                            <h4 className="font-medium text-gray-900 mb-2">Category</h4>
                                            <span className="inline-block px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                                                {activeJson.category}
                                            </span>
                                        </AnimatedCard>

                                        <AnimatedCard>
                                            <h4 className="font-medium text-gray-900 mb-2">Customer Profile</h4>
                                            <p className="text-gray-600 text-sm">{activeJson.customer_persona}</p>
                                        </AnimatedCard>

                                        {activeJson.coaching_suggestions.length > 0 && (
                                            <AnimatedCard>
                                                <h4 className="font-medium text-gray-900 mb-2">💡 Coaching Tips</h4>
                                                <ul className="space-y-1">
                                                    {activeJson.coaching_suggestions.map((tip, i) => (
                                                        <li key={`${tip}-${i}`} className="text-sm text-gray-600 flex items-start space-x-2">
                                                            <span className="text-purple-500 mt-1">•</span>
                                                            <span>{tip}</span>
                                                        </li>
                                                    ))}
                                                </ul>
                                            </AnimatedCard>
                                        )}
                                    </div>
                                </>
                            ) : (
                                <AnimatedCard className="text-center py-16">
                                    <div className="text-6xl mb-4">🤖</div>
                                    <h3 className="text-xl font-semibold text-gray-900 mb-2">Ready to Analyze</h3>
                                    <p className="text-gray-600">Click "Analyze This Call" to see AI insights</p>
                                </AnimatedCard>
                            )}
                        </div>
                    </div>
                )}

                {/* Results Overview */}
                {Object.keys(results).length > 0 && (
                    <div className="mt-12">
                        <AnimatedCard>
                            <h3 className="text-2xl font-bold text-gray-900 mb-6">Analysis Results</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                {Object.values(results).map((result) => (
                                    <div
                                        key={result.callId}
                                        className="p-6 bg-gradient-to-br from-gray-50 to-white rounded-xl border-2 border-gray-100 hover:border-purple-200 transition-colors"
                                    >
                                        <div className="flex items-start justify-between mb-4">
                                            <div>
                                                <h4 className="font-semibold text-gray-900 text-sm">{result.callId}</h4>
                                                <p className="text-xs text-gray-500">{result.category}</p>
                                            </div>
                                            <div className="text-right">
                                                <div className="text-2xl font-bold text-purple-600">{result.agent_empathy_score}</div>
                                                <div className="text-xs text-gray-500">empathy</div>
                                            </div>
                                        </div>

                                        <div className="flex flex-wrap gap-2 mb-3">
                                            {result.emotion_timeline.slice(0, 3).map((point, i) => {
                                                const cfg = toneConfig[point.tone] || toneConfig.neutral;
                                                return (
                                                    <span
                                                        key={`${result.callId}-${point.tone}-${i}`}
                                                        className="px-2 py-1 text-xs rounded-full text-white font-medium"
                                                        style={{ backgroundColor: cfg.color }}
                                                    >
                                                        {point.tone}
                                                    </span>
                                                );
                                            })}
                                        </div>

                                        <p className="text-xs text-gray-600">{result.customer_persona}</p>
                                    </div>
                                ))}
                            </div>
                        </AnimatedCard>
                    </div>
                )}
            </main>
        </div>
    );
}
